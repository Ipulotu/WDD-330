import QuakesController from './QuakesController.js';

let controller = new QuakesController("#quakeList");
controller.init();